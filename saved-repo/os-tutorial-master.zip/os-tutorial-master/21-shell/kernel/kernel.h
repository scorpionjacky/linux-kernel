#ifndef KERNEL_H
#define KERNEL_H

void user_input(char *input);

#endif
