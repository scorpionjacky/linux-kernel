int my_function() {
    int my_var = 0xbaba;
    return my_var;
}
