linux-0.01 On Ubuntu 18.04 with GCC-7.3

First of all, thanks Mariuz!

After a lot of time, I managed to compile this revised version of the first kernel on machines with Ubuntu 18.04 64 and 32 bit versions. So you can compile them and try them on 64 and 32 bit Intel machines.

The kernel runs in both emulators: QEMU ver. 2.11.1 and Bochs ver 2.6. and that was a great success for me ...

I also uploaded the bochsrc.txt file so that the bochs runs from the command line from the root where the kernel(Image) is
and qemu runs from the cmd line by the command: make run, but first unzip the file hd_oldlinux.img.zip.

Enjoy work and improvement.
sincerely 
Isoux
